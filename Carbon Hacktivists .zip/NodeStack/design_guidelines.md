# Carbon Coin Design Guidelines

## Design Approach
**Reference-Based Approach** - Drawing inspiration from **Notion** and **Linear** for clean productivity aesthetics, with environmental elements from sustainability-focused apps like **Forest** and **Ecosia**.

## Core Design Elements

### A. Color Palette
**Primary Colors:**
- Dark mode: Deep forest green (140 40% 25%) with bright accent green (140 60% 50%)
- Light mode: Fresh green (140 50% 40%) with lighter accent (140 40% 60%)

**Supporting Colors:**
- Success/Reward: Vibrant emerald (160 50% 45%)
- Background neutrals: Cool grays (210 8% 15%) for dark, (210 5% 95%) for light
- Text: High contrast whites/dark grays

### B. Typography
**Font Stack:** Inter from Google Fonts
- Headers: Inter 600-700 (semibold to bold)
- Body: Inter 400-500 (regular to medium)
- Coin values/stats: Inter 600 (semibold, larger sizes)

### C. Layout System
**Spacing Units:** Tailwind units of 3, 4, 6, 8, and 12
- Consistent use of p-4, m-6, gap-8 throughout
- Card spacing: p-6 internal, m-4 between cards
- Section spacing: py-12 for major sections

### D. Component Library

**Navigation:**
- Clean top nav with logo, coin counter, and profile
- Bottom nav for mobile with eco-themed icons
- Subtle green accent for active states

**Cards:**
- Rounded corners (rounded-lg)
- Subtle shadows with green tint
- Reward cards with coin animation areas

**Forms:**
- Minimal input styling with green focus states
- Clear validation with eco-friendly messaging
- Registration forms with environmental copy

**Buttons:**
- Primary: Green with white text
- Secondary: Outline green on transparent
- Success/Reward: Bright emerald for coin collection

**Dashboard Elements:**
- Coin counter as prominent hero element
- QR scanner button as primary CTA
- Recent activity feed with timeline styling
- Streak counter with progress indicators

### E. QR Scanner Interface
- Full-screen camera overlay with green scanning frame
- Clear instructions and eco-action confirmation
- Success animations with coin visual feedback

## Environmental Theming
- Leaf and recycling iconography throughout
- Subtle nature-inspired gradients (forest to lighter green)
- Clean, modern aesthetic that feels trustworthy and gamified
- Progress indicators styled as growing plants or filling containers

## Images
**Hero Section:** Large background image of the campus showing green spaces, solar panels, or students biking - with overlay text and blurred outline buttons
**About Section:** Smaller images showing QR codes at eco-stations, students using bike racks, and recycling bins
**Dashboard:** Small reward icons and achievement badges with nature themes

The design should feel like a modern productivity app with strong environmental values - clean, trustworthy, and engaging without being overly playful.