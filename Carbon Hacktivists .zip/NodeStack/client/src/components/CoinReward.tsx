import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coins, CheckCircle, MapPin } from "lucide-react";

interface CoinRewardProps {
  isVisible: boolean;
  onClose: () => void;
  ecoAction: string;
  coinsEarned: number;
  location: string;
}

export default function CoinReward({ 
  isVisible, 
  onClose, 
  ecoAction, 
  coinsEarned, 
  location 
}: CoinRewardProps) {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    if (isVisible) {
      setAnimate(true);
      const timer = setTimeout(() => {
        setAnimate(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <CardContent className="p-6 text-center">
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className={`transition-all duration-500 ${animate ? 'scale-110' : 'scale-100'}`}>
                <CheckCircle className="h-16 w-16 text-primary" />
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2" data-testid="text-reward-title">
                Great Job!
              </h3>
              <p className="text-muted-foreground" data-testid="text-eco-action">
                {ecoAction}
              </p>
            </div>

            <div className="flex items-center justify-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground" data-testid="text-location">
                {location}
              </span>
            </div>

            <Badge 
              variant="default" 
              className={`text-lg px-4 py-2 transition-all duration-500 ${
                animate ? 'scale-110 bg-primary' : 'scale-100'
              }`}
              data-testid="badge-coins-earned"
            >
              <Coins className="h-5 w-5 mr-2" />
              +{coinsEarned} Carbon Coins
            </Badge>

            <Button 
              onClick={onClose} 
              className="w-full"
              data-testid="button-reward-close"
            >
              Continue
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}