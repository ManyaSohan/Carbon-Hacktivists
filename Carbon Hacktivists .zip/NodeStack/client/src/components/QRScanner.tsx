import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, QrCode, Camera } from "lucide-react";

interface QRScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (result: string) => void;
}

export default function QRScanner({ isOpen, onClose, onScanSuccess }: QRScannerProps) {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isOpen) {
      requestCameraPermission();
    } else {
      stopScanning();
    }

    return () => stopScanning();
  }, [isOpen]);

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      setHasPermission(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsScanning(true);
      }
    } catch (error) {
      console.error('Camera permission denied:', error);
      setHasPermission(false);
    }
  };

  const stopScanning = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
  };

  const simulateQRScan = () => {
    // Simulate scanning eco-station QR codes
    const mockQRCodes = [
      "ECO_BIKE_RACK_01",
      "ECO_WATER_REFILL_02", 
      "ECO_RECYCLING_BIN_03",
      "ECO_SOLAR_PANEL_04",
      "ECO_COMPOST_BIN_05"
    ];
    const randomCode = mockQRCodes[Math.floor(Math.random() * mockQRCodes.length)];
    onScanSuccess(randomCode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" data-testid="text-scanner-title">Scan QR Code</h3>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              data-testid="button-scanner-close"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-4">
            {hasPermission === null && (
              <div className="text-center py-8">
                <Camera className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p data-testid="text-permission-requesting">Requesting camera permission...</p>
              </div>
            )}

            {hasPermission === false && (
              <div className="text-center py-8">
                <QrCode className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="mb-4" data-testid="text-permission-denied">Camera access denied</p>
                <Button onClick={requestCameraPermission} data-testid="button-retry-permission">
                  Try Again
                </Button>
              </div>
            )}

            {hasPermission === true && (
              <div className="space-y-4">
                <div className="relative bg-black rounded-lg overflow-hidden aspect-square">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                    data-testid="video-camera-feed"
                  />
                  <div className="absolute inset-0 border-2 border-primary rounded-lg m-8">
                    <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-primary"></div>
                    <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-primary"></div>
                    <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-primary"></div>
                    <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-primary"></div>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-4" data-testid="text-scan-instructions">
                    Point your camera at a QR code at an eco-station
                  </p>
                  <Button 
                    onClick={simulateQRScan}
                    className="w-full"
                    data-testid="button-simulate-scan"
                  >
                    <QrCode className="h-4 w-4 mr-2" />
                    Simulate Scan (Demo)
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}