import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Leaf, 
  Target, 
  Users, 
  Award,
  Recycle,
  Bike,
  Droplets,
  Sun,
  TreePine
} from "lucide-react";

interface AboutSectionProps {
  campusStats?: {
    totalUsers: number;
    coinsEarned: number;
    carbonSaved: number;
  };
}

export default function AboutSection({ campusStats }: AboutSectionProps) {
  const ecoActions = [
    {
      icon: Bike,
      title: "Cycle to Campus",
      description: "Use bike racks instead of driving",
      coins: "10 coins"
    },
    {
      icon: Droplets,
      title: "Refill Water Bottles",
      description: "Use water refill stations",
      coins: "5 coins"
    },
    {
      icon: Recycle,
      title: "Recycle Properly",
      description: "Use designated recycling bins",
      coins: "3 coins"
    },
    {
      icon: Sun,
      title: "Use Solar Charging",
      description: "Charge devices at solar stations",
      coins: "8 coins"
    },
    {
      icon: TreePine,
      title: "Campus Gardens",
      description: "Participate in gardening activities",
      coins: "15 coins"
    }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Mission Statement */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-primary" />
            Net Zero Campus Initiative
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-muted-foreground" data-testid="text-mission">
              Carbon Coin is part of our campus-wide commitment to achieving net zero carbon emissions. 
              By gamifying sustainable actions, we're creating a community of environmental champions 
              who make a real difference through everyday choices.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <Target className="h-8 w-8 text-primary mx-auto mb-2" />
                <h4 className="font-semibold" data-testid="text-goal-title">Our Goal</h4>
                <p className="text-sm text-muted-foreground">
                  Achieve carbon neutrality by 2030
                </p>
              </div>
              <div className="text-center">
                <Users className="h-8 w-8 text-primary mx-auto mb-2" />
                <h4 className="font-semibold" data-testid="text-community-title">Community</h4>
                <p className="text-sm text-muted-foreground">
                  Students, staff, and faculty united
                </p>
              </div>
              <div className="text-center">
                <Award className="h-8 w-8 text-primary mx-auto mb-2" />
                <h4 className="font-semibold" data-testid="text-impact-title">Impact</h4>
                <p className="text-sm text-muted-foreground">
                  Measurable environmental benefits
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* How It Works */}
      <Card>
        <CardHeader>
          <CardTitle>How to Earn Carbon Coins</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ecoActions.map((action, index) => (
              <div 
                key={index}
                className="p-4 rounded-lg border hover-elevate"
                data-testid={`eco-action-${index}`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <action.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h5 className="font-medium mb-1" data-testid={`action-title-${index}`}>
                      {action.title}
                    </h5>
                    <p className="text-sm text-muted-foreground mb-2">
                      {action.description}
                    </p>
                    <Badge variant="secondary" data-testid={`action-coins-${index}`}>
                      {action.coins}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Campus Impact */}
      {campusStats && (
        <Card>
          <CardHeader>
            <CardTitle>Campus Impact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-1" data-testid="text-total-users">
                  {campusStats.totalUsers.toLocaleString()}
                </div>
                <p className="text-sm text-muted-foreground">Active participants</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-1" data-testid="text-total-coins">
                  {campusStats.coinsEarned.toLocaleString()}
                </div>
                <p className="text-sm text-muted-foreground">Total coins earned</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-1" data-testid="text-carbon-saved">
                  {campusStats.carbonSaved}kg
                </div>
                <p className="text-sm text-muted-foreground">CO₂ equivalent saved</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Getting Started */}
      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3" data-testid="step-1">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-semibold mt-0.5">
                1
              </div>
              <div>
                <h5 className="font-medium">Look for QR codes around campus</h5>
                <p className="text-sm text-muted-foreground">
                  Find QR codes at bike racks, water stations, recycling bins, and other eco-friendly locations
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3" data-testid="step-2">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-semibold mt-0.5">
                2
              </div>
              <div>
                <h5 className="font-medium">Scan and take action</h5>
                <p className="text-sm text-muted-foreground">
                  Use the app to scan QR codes when you perform sustainable actions
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3" data-testid="step-3">
              <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-semibold mt-0.5">
                3
              </div>
              <div>
                <h5 className="font-medium">Earn coins and build streaks</h5>
                <p className="text-sm text-muted-foreground">
                  Collect Carbon Coins and maintain daily streaks to maximize your environmental impact
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}