import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Coins, QrCode, Menu, Moon, Sun } from "lucide-react";
import { useState } from "react";

interface HeaderProps {
  coinCount: number;
  userName: string;
  onQRScan: () => void;
  onMenuToggle: () => void;
  darkMode: boolean;
  onThemeToggle: () => void;
}

export default function Header({ 
  coinCount, 
  userName, 
  onQRScan, 
  onMenuToggle, 
  darkMode, 
  onThemeToggle 
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-16 items-center justify-between px-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onMenuToggle}
            className="md:hidden"
            data-testid="button-menu-toggle"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
              <Coins className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg" data-testid="text-app-title">Carbon Coin</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="px-3 py-1" data-testid="badge-coin-count">
            <Coins className="h-4 w-4 mr-1 text-primary" />
            {coinCount}
          </Badge>

          <Button 
            onClick={onQRScan}
            size="sm"
            className="hidden sm:flex"
            data-testid="button-qr-scan"
          >
            <QrCode className="h-4 w-4 mr-2" />
            Scan QR
          </Button>

          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onThemeToggle}
            data-testid="button-theme-toggle"
          >
            {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          <Avatar className="h-8 w-8" data-testid="avatar-user">
            <AvatarImage src="/placeholder-avatar.jpg" />
            <AvatarFallback>{userName.slice(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}