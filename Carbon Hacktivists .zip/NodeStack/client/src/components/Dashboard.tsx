import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Coins, 
  Flame, 
  TrendingUp, 
  Calendar,
  Recycle,
  Bike,
  Droplets,
  Sun
} from "lucide-react";

interface Transaction {
  id: string;
  action: string;
  coins: number;
  location: string;
  timestamp: Date;
  type: 'bike' | 'recycle' | 'water' | 'solar';
}

interface DashboardProps {
  totalCoins: number;
  streakCount: number;
  todayCoins: number;
  weeklyGoal: number;
  transactions: Transaction[];
}

const iconMap = {
  bike: Bike,
  recycle: Recycle,
  water: Droplets,
  solar: Sun,
};

export default function Dashboard({ 
  totalCoins, 
  streakCount, 
  todayCoins, 
  weeklyGoal, 
  transactions 
}: DashboardProps) {
  const weeklyProgress = (todayCoins / weeklyGoal) * 100;

  return (
    <div className="space-y-6 p-6">
      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Carbon Coins</CardTitle>
            <Coins className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-coins">{totalCoins}</div>
            <p className="text-xs text-muted-foreground">
              Your environmental impact score
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-streak-count">{streakCount}</div>
            <p className="text-xs text-muted-foreground">
              Days of eco-actions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-today-coins">{todayCoins}</div>
            <p className="text-xs text-muted-foreground">
              Coins earned today
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Goal Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Weekly Goal Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span data-testid="text-weekly-progress">{todayCoins} / {weeklyGoal} coins</span>
            </div>
            <Progress 
              value={Math.min(weeklyProgress, 100)} 
              className="h-2"
              data-testid="progress-weekly-goal"
            />
            <p className="text-xs text-muted-foreground">
              {weeklyProgress >= 100 
                ? "🎉 Goal achieved! Keep up the great work!" 
                : `${Math.round(100 - weeklyProgress)}% to go this week`
              }
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.length === 0 ? (
              <p className="text-center text-muted-foreground py-4" data-testid="text-no-activity">
                No activity yet. Start by scanning a QR code at an eco-station!
              </p>
            ) : (
              transactions.map((transaction) => {
                const IconComponent = iconMap[transaction.type];
                return (
                  <div 
                    key={transaction.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                    data-testid={`transaction-${transaction.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-full bg-primary/10">
                        <IconComponent className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium" data-testid={`text-action-${transaction.id}`}>
                          {transaction.action}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`text-location-${transaction.id}`}>
                          {transaction.location}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" data-testid={`badge-coins-${transaction.id}`}>
                        +{transaction.coins}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {transaction.timestamp.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}