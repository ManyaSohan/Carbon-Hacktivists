import CoinReward from '../CoinReward';
import { useState } from 'react';

export default function CoinRewardExample() {
  const [isVisible, setIsVisible] = useState(true);

  return (
    <CoinReward 
      isVisible={isVisible}
      onClose={() => setIsVisible(false)}
      ecoAction="Used bike rack instead of driving"
      coinsEarned={10}
      location="Main Campus - Building A"
    />
  );
}