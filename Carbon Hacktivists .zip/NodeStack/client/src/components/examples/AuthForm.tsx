import AuthForm from '../AuthForm';
import { useState } from 'react';

export default function AuthFormExample() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (username: string, password: string) => {
    setIsLoading(true);
    console.log('Login attempted:', { username, password });
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleRegister = (username: string, email: string, phone: string, password: string) => {
    setIsLoading(true);
    console.log('Registration attempted:', { username, email, phone, password });
    setTimeout(() => setIsLoading(false), 1000);
  };

  return (
    <AuthForm 
      onLogin={handleLogin}
      onRegister={handleRegister}
      isLoading={isLoading}
    />
  );
}