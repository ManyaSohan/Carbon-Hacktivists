import AboutSection from '../AboutSection';

export default function AboutSectionExample() {
  // TODO: remove mock data - replace with real campus statistics from backend
  const mockStats = {
    totalUsers: 2847,
    coinsEarned: 45621,
    carbonSaved: 1234
  };

  return (
    <AboutSection campusStats={mockStats} />
  );
}