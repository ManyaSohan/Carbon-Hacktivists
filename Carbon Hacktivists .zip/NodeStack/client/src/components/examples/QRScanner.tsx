import QRScanner from '../QRScanner';
import { useState } from 'react';

export default function QRScannerExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <QRScanner 
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      onScanSuccess={(result) => {
        console.log('QR scan successful:', result);
        setIsOpen(false);
      }}
    />
  );
}