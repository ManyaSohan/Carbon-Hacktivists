import Header from '../Header';
import { useState } from 'react';

export default function HeaderExample() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <Header 
      coinCount={125}
      userName="Alex Smith"
      onQRScan={() => console.log('QR scan triggered')}
      onMenuToggle={() => console.log('Menu toggle triggered')}
      darkMode={darkMode}
      onThemeToggle={() => setDarkMode(!darkMode)}
    />
  );
}