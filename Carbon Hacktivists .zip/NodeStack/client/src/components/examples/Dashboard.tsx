import Dashboard from '../Dashboard';

export default function DashboardExample() {
  // TODO: remove mock data - replace with real data from backend
  const mockTransactions = [
    {
      id: '1',
      action: 'Used bike rack',
      coins: 10,
      location: 'Main Campus - Building A',
      timestamp: new Date(),
      type: 'bike' as const
    },
    {
      id: '2', 
      action: 'Refilled water bottle',
      coins: 5,
      location: 'Student Center',
      timestamp: new Date(Date.now() - 86400000),
      type: 'water' as const
    },
    {
      id: '3',
      action: 'Used recycling bin',
      coins: 3,
      location: 'Library',
      timestamp: new Date(Date.now() - 172800000),
      type: 'recycle' as const
    }
  ];

  return (
    <Dashboard 
      totalCoins={125}
      streakCount={7}
      todayCoins={18}
      weeklyGoal={50}
      transactions={mockTransactions}
    />
  );
}