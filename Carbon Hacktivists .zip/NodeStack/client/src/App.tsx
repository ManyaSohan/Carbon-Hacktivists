import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { QrCode } from "lucide-react";
import { ThemeProvider, useTheme } from "@/components/ThemeProvider";
import Header from "@/components/Header";
import Dashboard from "@/components/Dashboard";
import AboutSection from "@/components/AboutSection";
import QRScanner from "@/components/QRScanner";
import CoinReward from "@/components/CoinReward";
import AuthForm from "@/components/AuthForm";
import NotFound from "@/pages/not-found";

interface Transaction {
  id: string;
  action: string;
  coins: number;
  location: string;
  timestamp: Date;
  type: 'bike' | 'recycle' | 'water' | 'solar';
}

function MainApp() {
  const { theme, setTheme } = useTheme();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState({ username: "Alex Smith" });
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [showReward, setShowReward] = useState(false);
  const [rewardData, setRewardData] = useState({ action: "", coins: 0, location: "" });
  
  // TODO: remove mock data - replace with real data from backend
  const [coinCount, setCoinCount] = useState(125);
  const [streakCount, setStreakCount] = useState(7);
  const [todayCoins, setTodayCoins] = useState(18);
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      action: 'Used bike rack',
      coins: 10,
      location: 'Main Campus - Building A',
      timestamp: new Date(),
      type: 'bike'
    },
    {
      id: '2', 
      action: 'Refilled water bottle',
      coins: 5,
      location: 'Student Center',
      timestamp: new Date(Date.now() - 86400000),
      type: 'water'
    },
    {
      id: '3',
      action: 'Used recycling bin',
      coins: 3,
      location: 'Library',
      timestamp: new Date(Date.now() - 172800000),
      type: 'recycle'
    }
  ]);

  const handleLogin = (username: string, password: string) => {
    // TODO: implement real authentication
    console.log('Login:', { username, password });
    setCurrentUser({ username });
    setIsAuthenticated(true);
  };

  const handleRegister = (username: string, email: string, phone: string, password: string) => {
    // TODO: implement real registration
    console.log('Register:', { username, email, phone, password });
    setCurrentUser({ username });
    setIsAuthenticated(true);
  };

  const handleQRScanSuccess = (qrCode: string) => {
    // TODO: validate QR code with backend
    console.log('QR scan successful:', qrCode);
    
    // Mock reward logic based on QR code type
    const rewards = {
      'ECO_BIKE_RACK_01': { action: 'Used bike rack instead of driving', coins: 10, location: 'Main Campus - Building A' },
      'ECO_WATER_REFILL_02': { action: 'Refilled water bottle', coins: 5, location: 'Student Center' },
      'ECO_RECYCLING_BIN_03': { action: 'Used recycling bin properly', coins: 3, location: 'Library' },
      'ECO_SOLAR_PANEL_04': { action: 'Charged device with solar power', coins: 8, location: 'Science Building' },
      'ECO_COMPOST_BIN_05': { action: 'Used compost bin', coins: 4, location: 'Cafeteria' }
    };
    
    const reward = rewards[qrCode as keyof typeof rewards] || 
                  { action: 'Eco-friendly action', coins: 5, location: 'Campus' };
    
    setRewardData(reward);
    setShowQRScanner(false);
    setShowReward(true);
    
    // Update user stats
    setCoinCount(prev => prev + reward.coins);
    setTodayCoins(prev => prev + reward.coins);
    
    // Add new transaction
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      action: reward.action,
      coins: reward.coins,
      location: reward.location,
      timestamp: new Date(),
      type: 'bike' // TODO: determine type from QR code
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  if (!isAuthenticated) {
    return (
      <AuthForm
        onLogin={handleLogin}
        onRegister={handleRegister}
      />
    );
  }

  const campusStats = {
    totalUsers: 2847,
    coinsEarned: 45621,
    carbonSaved: 1234
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        coinCount={coinCount}
        userName={currentUser.username}
        onQRScan={() => setShowQRScanner(true)}
        onMenuToggle={() => console.log('Menu toggle')}
        darkMode={theme === 'dark'}
        onThemeToggle={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      />
      
      <main className="max-w-7xl mx-auto">
        {/* Navigation tabs */}
        <div className="border-b">
          <nav className="flex space-x-8 px-6" data-testid="nav-tabs">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'dashboard'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground'
              }`}
              data-testid="tab-dashboard"
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'about'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground'
              }`}
              data-testid="tab-about"
            >
              About
            </button>
          </nav>
        </div>

        {/* Tab content */}
        {activeTab === 'dashboard' && (
          <Dashboard
            totalCoins={coinCount}
            streakCount={streakCount}
            todayCoins={todayCoins}
            weeklyGoal={50}
            transactions={transactions}
          />
        )}
        
        {activeTab === 'about' && (
          <AboutSection campusStats={campusStats} />
        )}
      </main>

      {/* Floating QR scan button for mobile */}
      <div className="fixed bottom-6 right-6 sm:hidden">
        <Button
          size="icon"
          className="h-14 w-14 rounded-full shadow-lg"
          onClick={() => setShowQRScanner(true)}
          data-testid="button-qr-scan-floating"
        >
          <QrCode className="h-6 w-6" />
        </Button>
      </div>

      {/* Modals */}
      <QRScanner
        isOpen={showQRScanner}
        onClose={() => setShowQRScanner(false)}
        onScanSuccess={handleQRScanSuccess}
      />
      
      <CoinReward
        isVisible={showReward}
        onClose={() => setShowReward(false)}
        ecoAction={rewardData.action}
        coinsEarned={rewardData.coins}
        location={rewardData.location}
      />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={MainApp} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider defaultTheme="light">
          <Toaster />
          <Router />
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
