import { useState } from 'react';
import Navigation from '@/components/Navigation';
import AnimatedTree from '@/components/AnimatedTree';
import CoinWallet from '@/components/CoinWallet';
import QRScanner from '@/components/QRScanner';
import HealthTracker from '@/components/HealthTracker';
import EducationSection from '@/components/EducationSection';
import BadgeSystem from '@/components/BadgeSystem';
import Leaderboard from '@/components/Leaderboard';
import PrizesPanel from '@/components/PrizesPanel';
import AboutPage from '@/pages/AboutPage';
import CourseDetailPage from '@/components/CourseDetailPage';

interface DashboardProps {
  onLogout?: () => void;
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const [userCoins, setUserCoins] = useState(125);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);

  //todo: remove mock functionality
  const mockBadges = ['Eco Hackstar', 'Carbon Cracker', 'Green Genie', 'Step Hustler'];

  const handleEarnCoins = (coins: number) => {
    setUserCoins(prev => prev + coins);
    console.log(`Earned ${coins} coins! Total: ${userCoins + coins}`);
  };

  const handleSpendCoins = (coins: number) => {
    if (userCoins >= coins) {
      setUserCoins(prev => prev - coins);
      console.log(`Spent ${coins} coins! Remaining: ${userCoins - coins}`);
      return true;
    }
    return false;
  };

  const handlePrizeRedeem = (prizeId: string) => {
    console.log(`Redeeming prize ${prizeId}`);
    // In real app, would check prize cost and deduct coins
  };

  const handleStartCourse = (courseId: string) => {
    setSelectedCourse(courseId);
    console.log(`Starting course ${courseId}`);
  };

  const handleBackFromCourse = () => {
    setSelectedCourse(null);
  };

  const renderCurrentPage = () => {
    // Show course detail if a course is selected
    if (selectedCourse) {
      return (
        <CourseDetailPage 
          courseId={selectedCourse}
          onBack={handleBackFromCourse}
          onStartCourse={handleStartCourse}
        />
      );
    }

    switch (currentPage) {
      case 'leaderboard':
        return (
          <div className="max-w-4xl mx-auto p-4">
            <h1 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Global Leaderboard</h1>
            <Leaderboard showAll={true} />
          </div>
        );
      case 'education':
        return (
          <div className="max-w-2xl mx-auto p-4">
            <h1 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Education Hub</h1>
            <EducationSection 
              userCoins={userCoins}
              onStartCourse={handleStartCourse}
            />
          </div>
        );
      case 'prizes':
        return (
          <div className="max-w-2xl mx-auto p-4">
            <h1 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Rewards & Resources</h1>
            <PrizesPanel 
              userCoins={userCoins}
              onRedeem={handlePrizeRedeem}
            />
          </div>
        );
      case 'about':
        return <AboutPage />;
      default:
        return (
          <div className="bg-gradient-to-br from-primary/3 via-background to-accent/3 min-h-screen">
            <div className="grid lg:grid-cols-4 gap-6 p-4">
              {/* Left Column - Tree & Wallet */}
              <div className="lg:col-span-1 space-y-6">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl blur-xl"></div>
                  <AnimatedTree coinBalance={userCoins} className="h-64 relative" />
                </div>
                <CoinWallet 
                  balance={userCoins}
                  streak={7}
                  todayEarned={15}
                  badges={mockBadges}
                />
              </div>

              {/* Center Column - Main Activities */}
              <div className="lg:col-span-2 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <QRScanner onScanSuccess={handleEarnCoins} />
                  <HealthTracker onLogActivity={handleEarnCoins} />
                </div>
                <EducationSection 
                  userCoins={userCoins}
                  onStartCourse={handleStartCourse}
                />
                <Leaderboard />
              </div>

              {/* Right Column - Badges & Prizes */}
              <div className="lg:col-span-1 space-y-6">
                <PrizesPanel 
                  userCoins={userCoins}
                  onRedeem={handlePrizeRedeem}
                />
                <BadgeSystem />
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        currentPage={currentPage}
        userCoins={userCoins}
        onNavigate={setCurrentPage}
        onLogout={onLogout}
      />
      
      <main className="container mx-auto">
        {renderCurrentPage()}
      </main>
    </div>
  );
}