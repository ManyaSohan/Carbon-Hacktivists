import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Leaf, Target, Users, Lightbulb, Globe, Award, TreePine, Recycle } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="p-4 rounded-full bg-primary/10">
              <Leaf className="h-12 w-12 text-primary" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">About Carbon Coin</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Revolutionizing sustainability through gamification, education, and community action
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Mission */}
          <Card className="hover-elevate" data-testid="card-mission">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Target className="h-6 w-6 text-primary" />
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                To create a sustainable future by empowering individuals and communities through 
                innovative gamification, making eco-friendly actions rewarding and accessible to everyone.
              </p>
              <p className="text-muted-foreground">
                We believe that small, consistent actions can create massive environmental impact 
                when multiplied across communities. Carbon Coin transforms sustainability from 
                a burden into an engaging, rewarding experience.
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                <Badge variant="secondary" className="text-xs">Sustainability</Badge>
                <Badge variant="secondary" className="text-xs">Education</Badge>
                <Badge variant="secondary" className="text-xs">Innovation</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Vision */}
          <Card className="hover-elevate" data-testid="card-vision">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <Globe className="h-6 w-6 text-accent" />
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                A world where sustainable living is the norm, achieved through collective action, 
                continuous learning, and technology-driven solutions that benefit both people and planet.
              </p>
              <p className="text-muted-foreground">
                We envision campuses and communities where every individual is an active participant 
                in the sustainability movement, equipped with knowledge, motivation, and tools to 
                make a meaningful difference.
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                <Badge variant="secondary" className="text-xs">Global Impact</Badge>
                <Badge variant="secondary" className="text-xs">Community</Badge>
                <Badge variant="secondary" className="text-xs">Technology</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Core Values */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Our Core Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover-elevate">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Lightbulb className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">Innovation</h3>
                <p className="text-sm text-muted-foreground">
                  Pioneering creative solutions for environmental challenges through technology
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-accent/10">
                    <Users className="h-8 w-8 text-accent" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">Community</h3>
                <p className="text-sm text-muted-foreground">
                  Building strong networks of environmentally conscious individuals
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <TreePine className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">Sustainability</h3>
                <p className="text-sm text-muted-foreground">
                  Promoting long-term environmental health and responsible resource use
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-accent/10">
                    <Award className="h-8 w-8 text-accent" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">Excellence</h3>
                <p className="text-sm text-muted-foreground">
                  Striving for the highest standards in education and environmental action
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* What We Do */}
        <Card className="hover-elevate mb-12" data-testid="card-what-we-do">
          <CardHeader>
            <CardTitle className="text-2xl text-center">What We Do</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-3">
                <div className="flex justify-center">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Recycle className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold">Gamify Sustainability</h3>
                <p className="text-sm text-muted-foreground">
                  Transform eco-friendly actions into rewarding experiences through our innovative 
                  Carbon Coin system, making sustainability engaging and fun.
                </p>
              </div>

              <div className="text-center space-y-3">
                <div className="flex justify-center">
                  <div className="p-3 rounded-full bg-accent/10">
                    <Users className="h-8 w-8 text-accent" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold">Build Communities</h3>
                <p className="text-sm text-muted-foreground">
                  Create networks of environmentally conscious students and professionals through 
                  leaderboards, competitions, and collaborative projects.
                </p>
              </div>

              <div className="text-center space-y-3">
                <div className="flex justify-center">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Lightbulb className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold">Educate & Empower</h3>
                <p className="text-sm text-muted-foreground">
                  Provide access to cutting-edge courses in AI, sustainability, and green technology 
                  to build the next generation of environmental leaders.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Impact Goals */}
        <Card className="hover-elevate" data-testid="card-impact-goals">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Our Impact Goals</CardTitle>
            <p className="text-center text-muted-foreground">
              Measurable outcomes we're working towards
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">10,000+</div>
                <div className="text-sm text-muted-foreground">Active Students</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-accent">500+</div>
                <div className="text-sm text-muted-foreground">Participating Colleges</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">1M+</div>
                <div className="text-sm text-muted-foreground">Eco Actions Completed</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-accent">50%</div>
                <div className="text-sm text-muted-foreground">Carbon Footprint Reduction</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Info */}
        <div className="text-center mt-12 pt-8 border-t border-border">
          <p className="text-muted-foreground">
            Ready to join the sustainability revolution?{' '}
            <span className="text-primary font-medium">Start earning Carbon Coins today!</span>
          </p>
        </div>
      </div>
    </div>
  );
}