import { useState } from 'react';
import AuthForm from '@/components/AuthForm';

interface AuthPageProps {
  onLogin?: (userData: any) => void;
}

export default function AuthPage({ onLogin }: AuthPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const handleSubmit = (data: { name?: string; email: string; password: string }) => {
    console.log(`${mode} attempt:`, data);
    
    // Simulate successful authentication
    const userData = {
      id: '1',
      name: data.name || 'Demo User',
      email: data.email,
      coins: mode === 'register' ? 0 : 125,
      streak: mode === 'register' ? 0 : 7,
    };
    
    onLogin?.(userData);
  };

  return (
    <AuthForm 
      mode={mode}
      onSubmit={handleSubmit}
      onToggleMode={() => setMode(mode === 'login' ? 'register' : 'login')}
    />
  );
}