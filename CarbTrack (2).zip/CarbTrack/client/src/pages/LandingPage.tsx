import HeroSection from '@/components/HeroSection';
import AnimatedTree from '@/components/AnimatedTree';
import CookieConsent from '@/components/CookieConsent';

interface LandingPageProps {
  onGetStarted?: () => void;
  onLearnMore?: () => void;
}

export default function LandingPage({ onGetStarted, onLearnMore }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="grid lg:grid-cols-2 min-h-screen">
        {/* Left side - Tree visualization */}
        <div className="hidden lg:flex items-center justify-center p-8 bg-gradient-to-br from-primary/5 to-accent/5">
          <AnimatedTree coinBalance={75} className="w-full max-w-md h-96" />
        </div>
        
        {/* Right side - Hero content */}
        <div className="flex items-center justify-center">
          <HeroSection 
            onGetStarted={onGetStarted}
            onLearnMore={onLearnMore}
          />
        </div>
      </div>
      
      {/* Mobile tree section */}
      <div className="lg:hidden p-8 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-sm mx-auto">
          <AnimatedTree coinBalance={75} className="h-64" />
        </div>
      </div>
      
      <CookieConsent />
    </div>
  );
}