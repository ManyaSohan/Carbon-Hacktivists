import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import LandingPage from "@/pages/LandingPage";
import AuthPage from "@/pages/AuthPage";
import Dashboard from "@/pages/Dashboard";
import NotFound from "@/pages/not-found";

interface User {
  id: string;
  name: string;
  email: string;
  coins: number;
  streak: number;
}

function Router() {
  const [user, setUser] = useState<User | null>(null);
  const [showAuth, setShowAuth] = useState(false);

  const handleGetStarted = () => {
    setShowAuth(true);
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    setShowAuth(false);
  };

  const handleLogout = () => {
    setUser(null);
    setShowAuth(false);
  };

  // If user is logged in, show dashboard
  if (user) {
    return <Dashboard onLogout={handleLogout} />;
  }

  // If showing auth, show auth page
  if (showAuth) {
    return <AuthPage onLogin={handleLogin} />;
  }

  // Default to landing page
  return (
    <Switch>
      <Route path="/">
        <LandingPage 
          onGetStarted={handleGetStarted}
          onLearnMore={() => console.log('Learn more clicked')}
        />
      </Route>
      <Route path="/auth">
        <AuthPage onLogin={handleLogin} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;