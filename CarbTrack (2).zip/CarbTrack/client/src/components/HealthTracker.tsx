import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Activity, Plus, Target } from 'lucide-react';

interface HealthTrackerProps {
  onLogActivity?: (coins: number) => void;
}

export default function HealthTracker({ onLogActivity }: HealthTrackerProps) {
  const [steps, setSteps] = useState('');
  const [workoutMinutes, setWorkoutMinutes] = useState('');
  const [todaySteps] = useState(6847); // Mock current steps
  const dailyGoal = 10000;
  const progress = (todaySteps / dailyGoal) * 100;

  const handleLogSteps = () => {
    const stepCount = parseInt(steps);
    if (stepCount > 0) {
      const coins = Math.floor(stepCount / 1000); // 1 coin per 1000 steps
      setSteps('');
      onLogActivity?.(coins);
      console.log(`Logged ${stepCount} steps, earned ${coins} coins`);
    }
  };

  const handleLogWorkout = () => {
    const minutes = parseInt(workoutMinutes);
    if (minutes > 0) {
      const coins = Math.floor(minutes / 10); // 1 coin per 10 minutes
      setWorkoutMinutes('');
      onLogActivity?.(coins);
      console.log(`Logged ${minutes} minute workout, earned ${coins} coins`);
    }
  };

  return (
    <Card className="hover-elevate" data-testid="card-health-tracker">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Health Tracker</CardTitle>
        <Activity className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Daily Steps Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Daily Steps</span>
            <span className="text-sm text-muted-foreground">{todaySteps.toLocaleString()}/{dailyGoal.toLocaleString()}</span>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Target className="h-3 w-3" />
            <span>{(dailyGoal - todaySteps).toLocaleString()} steps to go</span>
          </div>
        </div>

        {/* Manual Step Entry */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Log Additional Steps</label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Enter steps"
              value={steps}
              onChange={(e) => setSteps(e.target.value)}
              data-testid="input-steps"
            />
            <Button 
              onClick={handleLogSteps}
              disabled={!steps}
              size="sm"
              className="hover-elevate active-elevate-2"
              data-testid="button-log-steps"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Workout Logging */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Log Workout (minutes)</label>
          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Workout duration"
              value={workoutMinutes}
              onChange={(e) => setWorkoutMinutes(e.target.value)}
              data-testid="input-workout"
            />
            <Button 
              onClick={handleLogWorkout}
              disabled={!workoutMinutes}
              size="sm"
              className="hover-elevate active-elevate-2"
              data-testid="button-log-workout"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center">
          Earn 1 coin per 1000 steps • 1 coin per 10 minutes workout
        </div>
      </CardContent>
    </Card>
  );
}