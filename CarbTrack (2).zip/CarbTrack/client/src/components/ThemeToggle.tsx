import { Button } from '@/components/ui/button';
import { Sun, Moon, Sunset } from 'lucide-react';
import { useTheme } from './ThemeProvider';

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const getNextTheme = () => {
    switch (theme) {
      case 'light': return 'dark';
      case 'dark': return 'night';
      case 'night': return 'light';
      default: return 'light';
    }
  };

  const getIcon = () => {
    switch (theme) {
      case 'light': return <Sun className="h-4 w-4" />;
      case 'dark': return <Moon className="h-4 w-4" />;
      case 'night': return <Sunset className="h-4 w-4" />;
      default: return <Sun className="h-4 w-4" />;
    }
  };

  const getLabel = () => {
    switch (theme) {
      case 'light': return 'Light';
      case 'dark': return 'Dark';
      case 'night': return 'Night';
      default: return 'Light';
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => setTheme(getNextTheme())}
      className="hover-elevate active-elevate-2"
      data-testid="button-theme-toggle"
      title={`Switch to ${getNextTheme()} mode`}
    >
      {getIcon()}
      <span className="ml-2 hidden sm:inline">{getLabel()}</span>
    </Button>
  );
}