import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Menu, X, Leaf, Home, Trophy, BookOpen, Gift, Settings, User, Info } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

interface NavigationProps {
  currentPage?: string;
  userCoins?: number;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

export default function Navigation({ currentPage = 'dashboard', userCoins = 0, onNavigate, onLogout }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'education', label: 'Education', icon: BookOpen },
    { id: 'prizes', label: 'Prizes', icon: Gift },
    { id: 'about', label: 'About Us', icon: Info },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNavigate = (page: string) => {
    onNavigate?.(page);
    setIsMobileMenuOpen(false);
    console.log(`Navigating to ${page}`);
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="bg-background/95 backdrop-blur-sm border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <Leaf className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Carbon Coin</h1>
                <p className="text-xs text-muted-foreground">Sustainability Rewards</p>
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-1">
              {menuItems.slice(0, 4).map((item) => (
                <Button
                  key={item.id}
                  variant={currentPage === item.id ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleNavigate(item.id)}
                  className="hover-elevate active-elevate-2"
                  data-testid={`nav-${item.id}`}
                >
                  <item.icon className="h-4 w-4 mr-2" />
                  {item.label}
                </Button>
              ))}
            </div>

            {/* User Info & Mobile Menu */}
            <div className="flex items-center gap-3">
              {/* Coins Display */}
              <Badge variant="secondary" className="hidden sm:flex items-center gap-1">
                <Leaf className="h-3 w-3 text-primary" />
                <span className="font-mono">{userCoins}</span>
              </Badge>

              {/* Theme, Profile & Settings */}
              <div className="hidden md:flex items-center gap-1">
                <ThemeToggle />
                <Button
                  variant={currentPage === 'about' ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleNavigate('about')}
                  className="hover-elevate active-elevate-2"
                  data-testid="nav-about"
                >
                  <Info className="h-4 w-4" />
                </Button>
                <Button
                  variant={currentPage === 'profile' ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleNavigate('profile')}
                  className="hover-elevate active-elevate-2"
                  data-testid="nav-profile"
                >
                  <User className="h-4 w-4" />
                </Button>
                <Button
                  variant={currentPage === 'settings' ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleNavigate('settings')}
                  className="hover-elevate active-elevate-2"
                  data-testid="nav-settings"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden hover-elevate active-elevate-2"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                data-testid="button-mobile-menu"
              >
                {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 md:hidden">
          <div className="flex flex-col h-full">
            {/* Mobile Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">Carbon Coin</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMobileMenuOpen(false)}
                data-testid="button-close-mobile-menu"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            {/* Coins Display Mobile */}
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-center gap-2 p-3 bg-primary/10 rounded-lg">
                <Leaf className="h-5 w-5 text-primary" />
                <span className="text-lg font-bold text-primary">{userCoins} Carbon Coins</span>
              </div>
            </div>

            {/* Mobile Menu Items */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {menuItems.map((item) => (
                <Button
                  key={item.id}
                  variant={currentPage === item.id ? "default" : "ghost"}
                  className="w-full justify-start text-left hover-elevate active-elevate-2"
                  onClick={() => handleNavigate(item.id)}
                  data-testid={`mobile-nav-${item.id}`}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.label}
                </Button>
              ))}
            </div>

            {/* Mobile Footer */}
            <div className="p-4 border-t border-border">
              <Button
                variant="outline"
                className="w-full hover-elevate active-elevate-2"
                onClick={onLogout}
                data-testid="button-logout"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}