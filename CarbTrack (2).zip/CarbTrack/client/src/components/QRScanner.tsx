import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { QrCode, MapPin, CheckCircle, AlertCircle, Camera, X } from 'lucide-react';
import QrScanner from 'qr-scanner';

// Configure QR Scanner worker path
if (typeof window !== 'undefined') {
  QrScanner.WORKER_PATH = new URL('qr-scanner-worker.min.js', import.meta.url).toString();
}

interface QRScannerProps {
  onScanSuccess?: (coins: number) => void;
}

export default function QRScanner({ onScanSuccess }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<'success' | 'failed' | null>(null);
  const [lastEarned, setLastEarned] = useState(0);
  const [scannedValue, setScannedValue] = useState('');
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const qrScannerRef = useRef<QrScanner | null>(null);

  useEffect(() => {
    return () => {
      // Cleanup scanner when component unmounts
      if (qrScannerRef.current) {
        qrScannerRef.current.destroy();
      }
    };
  }, []);

  const startScanning = async () => {
    setShowCamera(true);
    setIsScanning(true);
    setScanResult(null);
    
    try {
      // Check if camera is available
      const hasCamera = await QrScanner.hasCamera();
      if (!hasCamera) {
        throw new Error('No camera available');
      }
      
      if (videoRef.current) {
        qrScannerRef.current = new QrScanner(
          videoRef.current,
          async (result) => {
            setScannedValue(result.data);
            await handleQRDetected(result.data);
          },
          {
            highlightScanRegion: true,
            highlightCodeOutline: true,
            preferredCamera: 'environment', // Use back camera if available
          }
        );
        
        await qrScannerRef.current.start();
        console.log('QR Scanner started successfully');
      }
    } catch (error) {
      console.error('Error starting QR scanner:', error);
      setIsScanning(false);
      setShowCamera(false);
      // Set a helpful error state
      setScanResult('failed');
      setTimeout(() => setScanResult(null), 3000);
    }
  };

  const stopScanning = () => {
    if (qrScannerRef.current) {
      qrScannerRef.current.stop();
      qrScannerRef.current.destroy();
      qrScannerRef.current = null;
    }
    setIsScanning(false);
    setShowCamera(false);
  };

  const handleQRDetected = async (qrData: string) => {
    // Always return "Dayananda Sagar College of Engineering" regardless of QR content
    const institutionName = "Dayananda Sagar College of Engineering";
    
    // Simulate location validation
    const isValidLocation = true; // Always valid for demo
    const coinsEarned = Math.floor(Math.random() * 15) + 10; // 10-25 coins
    
    stopScanning();
    
    if (isValidLocation) {
      setScanResult('success');
      setLastEarned(coinsEarned);
      onScanSuccess?.(coinsEarned);
      console.log(`QR Code detected: ${qrData}`);
      console.log(`Verified location: ${institutionName}`);
      console.log(`Earned ${coinsEarned} coins!`);
    } else {
      setScanResult('failed');
    }
    
    // Reset after 3 seconds
    setTimeout(() => setScanResult(null), 3000);
  };

  const handleScan = () => {
    if (showCamera) {
      stopScanning();
    } else {
      startScanning();
    }
  };

  return (
    <Card className="hover-elevate" data-testid="card-qr-scanner">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Eco Actions</CardTitle>
        <QrCode className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          {showCamera ? (
            <div className="relative w-64 h-64 mx-auto mb-4 border-2 border-primary rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={stopScanning}
                className="absolute top-2 right-2 bg-background/80 hover-elevate"
                data-testid="button-stop-scanning"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="w-32 h-32 mx-auto mb-4 border-2 border-dashed border-muted-foreground/50 rounded-lg flex items-center justify-center bg-muted/20">
              {isScanning ? (
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              ) : (
                <Camera className="h-8 w-8 text-muted-foreground" />
              )}
            </div>
          )}
          
          {scanResult === 'success' && (
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-center gap-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">+{lastEarned} Carbon Coins!</span>
              </div>
              <div className="text-xs text-center text-muted-foreground">
                Location verified: Dayananda Sagar College of Engineering
              </div>
            </div>
          )}
          
          {scanResult === 'failed' && (
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-center gap-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                <span className="font-medium">Scan failed</span>
              </div>
              <div className="text-xs text-center text-muted-foreground">
                {scannedValue ? 'Location not verified' : 'Camera error or no QR code detected'}
              </div>
            </div>
          )}
          
          <p className="text-sm text-muted-foreground mb-4">
            {showCamera 
              ? 'Point camera at QR code to scan'
              : 'Scan QR codes to earn coins. Location verification required.'
            }
          </p>
        </div>
        
        <Button 
          onClick={handleScan}
          disabled={isScanning && !showCamera}
          className="w-full hover-elevate active-elevate-2"
          data-testid="button-scan-qr"
        >
          {showCamera ? 'Stop Scanner' : isScanning ? 'Starting Camera...' : 'Scan QR Code'}
          {showCamera ? <X className="ml-2 h-4 w-4" /> : <MapPin className="ml-2 h-4 w-4" />}
        </Button>
        
        <div className="text-xs text-muted-foreground text-center">
          <div className="flex items-center justify-center gap-1">
            <MapPin className="h-3 w-3" />
            <span>GPS verification ensures authentic scans</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}