import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Award, Star, Zap, Leaf, Recycle, Car, Footprints, TreePine, Crown } from 'lucide-react';
import badgeImage from '@assets/generated_images/Eco_achievement_badges_c08386cb.png';

interface UserBadge {
  id: string;
  name: string;
  description: string;
  earned: boolean;
  earnedDate?: string;
  icon: string;
}

interface BadgeSystemProps {
  badges?: UserBadge[];
}

export default function BadgeSystem({ badges = [] }: BadgeSystemProps) {
  //todo: remove mock functionality
  const defaultBadges: UserBadge[] = [
    { id: '1', name: 'Eco Hackstar', description: 'Scanned 10 dustbin QR codes', earned: true, earnedDate: '2024-01-15', icon: 'leaf' },
    { id: '2', name: 'Carbon Cracker', description: 'Earned 100 Carbon Coins', earned: true, earnedDate: '2024-01-20', icon: 'star' },
    { id: '3', name: 'Emissions Ninja', description: 'Completed Carbon Emission course', earned: false, earnedDate: undefined, icon: 'zap' },
    { id: '4', name: 'Green Genie', description: 'Maintained 7-day streak', earned: true, earnedDate: '2024-01-25', icon: 'crown' },
    { id: '5', name: 'ML Boss', description: 'Completed ML Fundamentals', earned: false, earnedDate: undefined, icon: 'star' },
    { id: '6', name: 'Recycle Rockstar', description: 'Scanned 50 recycling points', earned: false, earnedDate: undefined, icon: 'recycle' },
    { id: '7', name: 'Step Hustler', description: 'Logged 100,000 steps total', earned: true, earnedDate: '2024-01-30', icon: 'footprints' },
    { id: '8', name: 'EV Explorer', description: 'Completed EV Technology course', earned: false, earnedDate: undefined, icon: 'car' },
    { id: '9', name: 'Treefluencer', description: 'Grew tree to maximum level', earned: false, earnedDate: undefined, icon: 'tree' },
  ];

  const userBadges = badges.length > 0 ? badges : defaultBadges;
  const earnedBadges = userBadges.filter(badge => badge.earned);
  const totalBadges = userBadges.length;

  const getIcon = (iconName: string) => {
    const icons = {
      leaf: Leaf,
      star: Star,
      zap: Zap,
      crown: Crown,
      recycle: Recycle,
      footprints: Footprints,
      car: Car,
      tree: TreePine,
    };
    const IconComponent = icons[iconName as keyof typeof icons] || Award;
    return <IconComponent className="h-4 w-4" />;
  };

  return (
    <Card className="hover-elevate" data-testid="card-badges">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Achievement Badges</CardTitle>
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 text-primary" />
          <Badge variant="secondary" className="text-xs">
            {earnedBadges.length}/{totalBadges}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center mb-4">
          <img 
            src={badgeImage} 
            alt="Achievement badges preview" 
            className="w-full h-20 object-cover rounded-lg opacity-60"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {userBadges.map((badge) => (
            <div 
              key={badge.id}
              className={`p-3 rounded-lg border transition-all duration-200 hover-elevate ${
                badge.earned 
                  ? 'bg-primary/10 border-primary/20' 
                  : 'bg-muted/50 border-muted-foreground/20'
              }`}
              data-testid={`badge-${badge.id}`}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className={`p-1 rounded ${badge.earned ? 'text-primary' : 'text-muted-foreground'}`}>
                  {getIcon(badge.icon)}
                </div>
                <h4 className={`font-medium text-xs ${badge.earned ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {badge.name}
                </h4>
              </div>
              <p className="text-xs text-muted-foreground mb-2">
                {badge.description}
              </p>
              {badge.earned && badge.earnedDate && (
                <Badge variant="secondary" className="text-xs">
                  Earned {new Date(badge.earnedDate).toLocaleDateString()}
                </Badge>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}