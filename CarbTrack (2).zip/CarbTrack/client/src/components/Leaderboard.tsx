import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, TrendingUp, Users, Crown, Medal, Award } from 'lucide-react';

interface College {
  id: string;
  name: string;
  points: number;
  rank: number;
  trend: 'up' | 'down' | 'same';
  students: number;
}

interface LeaderboardProps {
  colleges?: College[];
  showAll?: boolean;
}

export default function Leaderboard({ colleges = [], showAll = false }: LeaderboardProps) {
  //todo: remove mock functionality
  const defaultColleges: College[] = [
    { id: '1', name: 'Dayananda Sagar College of Engineering', points: 12450, rank: 1, trend: 'up', students: 342 },
    { id: '2', name: 'RV College of Engineering', points: 11890, rank: 2, trend: 'up', students: 298 },
    { id: '3', name: 'PES University', points: 11200, rank: 3, trend: 'same', students: 267 },
    { id: '4', name: 'BMS College of Engineering', points: 10750, rank: 4, trend: 'down', students: 234 },
    { id: '5', name: 'MS Ramaiah Institute of Technology', points: 10200, rank: 5, trend: 'up', students: 189 },
    { id: '6', name: 'Sir M Visvesvaraya Institute of Technology', points: 9800, rank: 6, trend: 'down', students: 156 },
    { id: '7', name: 'New Horizon College of Engineering', points: 9400, rank: 7, trend: 'up', students: 123 },
    { id: '8', name: 'Bangalore Institute of Technology', points: 9100, rank: 8, trend: 'same', students: 98 },
  ];

  const leaderboardData = colleges.length > 0 ? colleges : defaultColleges;
  const displayData = showAll ? leaderboardData : leaderboardData.slice(0, 5);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-5 w-5 text-yellow-500" />;
      case 2: return <Medal className="h-5 w-5 text-gray-400" />;
      case 3: return <Award className="h-5 w-5 text-amber-600" />;
      default: return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getTrendIcon = (trend: College['trend']) => {
    const className = "h-4 w-4";
    switch (trend) {
      case 'up': return <TrendingUp className={`${className} text-green-500`} />;
      case 'down': return <TrendingUp className={`${className} text-red-500 rotate-180`} />;
      default: return <div className={`${className}`}></div>;
    }
  };

  return (
    <Card className="hover-elevate" data-testid="card-leaderboard">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Bengaluru Colleges Leaderboard</CardTitle>
        <Trophy className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-3">
        {displayData.map((college, index) => (
          <div 
            key={college.id}
            className={`p-3 rounded-lg border transition-all duration-300 hover-elevate ${
              college.rank === 1 
                ? 'bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200' 
                : college.rank <= 3 
                  ? 'bg-muted/50 border-muted-foreground/20'
                  : 'bg-background border-border'
            }`}
            style={{ 
              animationDelay: `${index * 100}ms`,
              animation: 'slideInLeft 0.5s ease-out forwards'
            }}
            data-testid={`college-rank-${college.rank}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="flex items-center justify-center w-8">
                  {getRankIcon(college.rank)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className={`font-medium text-sm truncate ${
                    college.rank === 1 ? 'text-yellow-800' : 'text-foreground'
                  }`}>
                    {college.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Users className="h-3 w-3" />
                      <span>{college.students} students</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {getTrendIcon(college.trend)}
                <Badge 
                  variant={college.rank === 1 ? "default" : "secondary"}
                  className="text-xs font-mono"
                >
                  {college.points.toLocaleString()} pts
                </Badge>
              </div>
            </div>
          </div>
        ))}
        
        {!showAll && leaderboardData.length > 5 && (
          <div className="text-center text-sm text-muted-foreground">
            +{leaderboardData.length - 5} more colleges
          </div>
        )}
      </CardContent>
    </Card>
  );
}