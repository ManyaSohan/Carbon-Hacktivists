import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Play, Clock, Users, Award, CheckCircle, BookOpen } from 'lucide-react';

interface CourseDetailPageProps {
  courseId: string;
  onBack?: () => void;
  onStartCourse?: (courseId: string) => void;
}

interface CourseData {
  id: string;
  title: string;
  category: 'AI' | 'ML' | 'Cybersecurity' | 'Carbon Emission' | 'EVs';
  instructor: string;
  duration: string;
  students: number;
  rating: number;
  description: string;
  learningOutcomes: string[];
  modules: Array<{
    id: string;
    title: string;
    duration: string;
    completed: boolean;
  }>;
  prerequisites: string[];
  coinsRequired: number;
  coinsReward: number;
  progress: number;
  logo: string;
}

export default function CourseDetailPage({ courseId, onBack, onStartCourse }: CourseDetailPageProps) {
  //todo: remove mock functionality
  const courseData: Record<string, CourseData> = {
    '1': {
      id: '1',
      title: 'AI Fundamentals for Sustainability',
      category: 'AI',
      instructor: 'Dr. Sarah Chen',
      duration: '6 weeks',
      students: 1247,
      rating: 4.8,
      description: 'Learn how artificial intelligence can be applied to solve environmental challenges and promote sustainable development. This comprehensive course covers machine learning applications in climate science, energy optimization, and resource management.',
      learningOutcomes: [
        'Understand AI applications in environmental science',
        'Implement machine learning models for sustainability',
        'Analyze environmental data using AI tools',
        'Design AI solutions for green technology'
      ],
      modules: [
        { id: '1', title: 'Introduction to AI for Environment', duration: '45 min', completed: true },
        { id: '2', title: 'Machine Learning in Climate Science', duration: '60 min', completed: true },
        { id: '3', title: 'AI for Energy Optimization', duration: '50 min', completed: false },
        { id: '4', title: 'Smart Resource Management', duration: '55 min', completed: false },
        { id: '5', title: 'Project: Green AI Application', duration: '90 min', completed: false }
      ],
      prerequisites: ['Basic programming knowledge', 'Mathematics fundamentals'],
      coinsRequired: 0,
      coinsReward: 50,
      progress: 40,
      logo: '🤖'
    },
    '2': {
      id: '2',
      title: 'Machine Learning for Environmental Data',
      category: 'ML',
      instructor: 'Prof. Michael Rodriguez',
      duration: '8 weeks',
      students: 892,
      rating: 4.9,
      description: 'Master machine learning techniques specifically designed for environmental data analysis. Learn to predict climate patterns, analyze pollution data, and build models for sustainable development.',
      learningOutcomes: [
        'Process and analyze environmental datasets',
        'Build predictive models for climate patterns',
        'Implement ML algorithms for pollution monitoring',
        'Create data-driven sustainability solutions'
      ],
      modules: [
        { id: '1', title: 'Environmental Data Types', duration: '40 min', completed: false },
        { id: '2', title: 'Data Preprocessing for Climate Data', duration: '55 min', completed: false },
        { id: '3', title: 'Time Series Analysis', duration: '65 min', completed: false },
        { id: '4', title: 'Predictive Modeling', duration: '70 min', completed: false },
        { id: '5', title: 'Model Deployment', duration: '50 min', completed: false }
      ],
      prerequisites: ['Python programming', 'Statistics basics', 'AI Fundamentals'],
      coinsRequired: 25,
      coinsReward: 60,
      progress: 0,
      logo: '🧠'
    },
    '3': {
      id: '3',
      title: 'Cybersecurity for Green Infrastructure',
      category: 'Cybersecurity',
      instructor: 'Dr. Lisa Wang',
      duration: '5 weeks',
      students: 634,
      rating: 4.7,
      description: 'Protect sustainable infrastructure and green technologies from cyber threats. Learn about security challenges in smart grids, IoT environmental sensors, and renewable energy systems.',
      learningOutcomes: [
        'Secure IoT environmental monitoring systems',
        'Protect smart grid infrastructure',
        'Implement security for renewable energy systems',
        'Develop incident response for green tech'
      ],
      modules: [
        { id: '1', title: 'Green Infrastructure Overview', duration: '35 min', completed: false },
        { id: '2', title: 'IoT Security for Environmental Sensors', duration: '50 min', completed: false },
        { id: '3', title: 'Smart Grid Security', duration: '60 min', completed: false },
        { id: '4', title: 'Renewable Energy System Protection', duration: '45 min', completed: false }
      ],
      prerequisites: ['Network security basics', 'Understanding of IoT systems'],
      coinsRequired: 50,
      coinsReward: 70,
      progress: 0,
      logo: '🔒'
    },
    '4': {
      id: '4',
      title: 'Carbon Footprint Analysis & Reduction',
      category: 'Carbon Emission',
      instructor: 'Dr. James Taylor',
      duration: '4 weeks',
      students: 1156,
      rating: 4.9,
      description: 'Learn to measure, analyze, and reduce carbon emissions across various industries. Master lifecycle assessment, carbon accounting, and emission reduction strategies.',
      learningOutcomes: [
        'Calculate organizational carbon footprints',
        'Perform lifecycle assessments',
        'Develop emission reduction strategies',
        'Create sustainability reports'
      ],
      modules: [
        { id: '1', title: 'Carbon Accounting Fundamentals', duration: '40 min', completed: false },
        { id: '2', title: 'Lifecycle Assessment Methods', duration: '55 min', completed: false },
        { id: '3', title: 'Emission Reduction Strategies', duration: '50 min', completed: false },
        { id: '4', title: 'Reporting and Compliance', duration: '45 min', completed: false }
      ],
      prerequisites: ['Environmental science basics'],
      coinsRequired: 20,
      coinsReward: 80,
      progress: 0,
      logo: '🌱'
    },
    '5': {
      id: '5',
      title: 'Electric Vehicle Technology & Systems',
      category: 'EVs',
      instructor: 'Eng. Maria Silva',
      duration: '7 weeks',
      students: 743,
      rating: 4.8,
      description: 'Comprehensive course on electric vehicle technology, battery systems, charging infrastructure, and the future of sustainable transportation.',
      learningOutcomes: [
        'Understand EV battery technology',
        'Design charging infrastructure',
        'Analyze EV performance metrics',
        'Plan sustainable transportation systems'
      ],
      modules: [
        { id: '1', title: 'EV Technology Overview', duration: '45 min', completed: false },
        { id: '2', title: 'Battery Systems and Management', duration: '60 min', completed: false },
        { id: '3', title: 'Charging Infrastructure', duration: '55 min', completed: false },
        { id: '4', title: 'Performance Optimization', duration: '50 min', completed: false },
        { id: '5', title: 'Future of Transportation', duration: '40 min', completed: false }
      ],
      prerequisites: ['Basic electrical engineering', 'Automotive knowledge'],
      coinsRequired: 75,
      coinsReward: 90,
      progress: 0,
      logo: '🚗'
    }
  };

  const course = courseData[courseId];
  const [isEnrolled, setIsEnrolled] = useState(course?.progress > 0);

  if (!course) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="text-center p-8">
            <h2 className="text-xl font-bold mb-4">Course Not Found</h2>
            <Button onClick={onBack} variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleStartCourse = () => {
    setIsEnrolled(true);
    onStartCourse?.(courseId);
    console.log(`Starting course: ${course.title}`);
  };

  const completedModules = course.modules.filter(m => m.completed).length;
  const totalModules = course.modules.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            onClick={onBack}
            className="hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Courses
          </Button>
          <div className="h-6 w-px bg-border"></div>
          <Badge variant="secondary" className="text-sm">
            {course.category}
          </Badge>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Course Header */}
            <Card className="hover-elevate">
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{course.logo}</div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2">{course.title}</CardTitle>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {course.students.toLocaleString()} students
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {course.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <Award className="h-4 w-4" />
                        {course.rating}/5.0
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Instructor: {course.instructor}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isEnrolled && course.progress > 0 && (
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progress</span>
                      <span>{completedModules}/{totalModules} modules completed</span>
                    </div>
                    <Progress value={course.progress} className="h-2" />
                  </div>
                )}
                <p className="text-foreground leading-relaxed">{course.description}</p>
              </CardContent>
            </Card>

            {/* Learning Outcomes */}
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg">What You'll Learn</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {course.learningOutcomes.map((outcome, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{outcome}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Course Modules */}
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg">Course Content</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {totalModules} modules • {course.duration} total
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {course.modules.map((module, index) => (
                    <div 
                      key={module.id}
                      className={`p-3 rounded-lg border ${
                        module.completed 
                          ? 'bg-primary/10 border-primary/20' 
                          : isEnrolled 
                            ? 'bg-background border-border hover-elevate' 
                            : 'bg-muted/50 border-muted-foreground/20'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-muted text-xs font-medium">
                            {index + 1}
                          </div>
                          <div>
                            <h4 className={`font-medium text-sm ${
                              module.completed ? 'text-primary' : 'text-foreground'
                            }`}>
                              {module.title}
                            </h4>
                            <p className="text-xs text-muted-foreground">{module.duration}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {module.completed ? (
                            <CheckCircle className="h-4 w-4 text-primary" />
                          ) : isEnrolled ? (
                            <Button size="sm" variant="ghost" className="h-6 text-xs">
                              <Play className="h-3 w-3" />
                            </Button>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Enrollment Card */}
            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <div className="text-3xl mb-2">{course.logo}</div>
                  {!isEnrolled ? (
                    <>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Required:</span>
                          <span className="font-medium">{course.coinsRequired} coins</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span>Reward:</span>
                          <span className="font-medium text-primary">+{course.coinsReward} coins</span>
                        </div>
                      </div>
                      <Button 
                        onClick={handleStartCourse}
                        className="w-full hover-elevate active-elevate-2"
                        data-testid="button-enroll"
                      >
                        <BookOpen className="mr-2 h-4 w-4" />
                        Start Course
                      </Button>
                    </>
                  ) : (
                    <>
                      <Badge variant="secondary" className="w-full justify-center py-2">
                        Enrolled
                      </Badge>
                      <Button 
                        onClick={() => console.log('Continue learning')}
                        className="w-full hover-elevate active-elevate-2"
                        data-testid="button-continue"
                      >
                        <Play className="mr-2 h-4 w-4" />
                        Continue Learning
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Prerequisites */}
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg">Prerequisites</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {course.prerequisites.map((prereq, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                      <span>{prereq}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}