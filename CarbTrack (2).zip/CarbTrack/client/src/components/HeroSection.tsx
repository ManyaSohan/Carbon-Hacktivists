import { Button } from '@/components/ui/button';
import { Leaf, Coins, TreePine } from 'lucide-react';

interface HeroSectionProps {
  onGetStarted?: () => void;
  onLearnMore?: () => void;
}

export default function HeroSection({ onGetStarted, onLearnMore }: HeroSectionProps) {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-primary/8 via-background to-accent/8 overflow-hidden">
      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 animate-bounce delay-75">
          <Leaf className="w-8 h-8 text-primary/40" />
        </div>
        <div className="absolute top-40 right-32 animate-bounce delay-150">
          <Coins className="w-6 h-6 text-accent/40" />
        </div>
        <div className="absolute bottom-40 left-32 animate-bounce delay-300">
          <TreePine className="w-10 h-10 text-primary/30" />
        </div>
        <div className="absolute top-60 left-1/2 animate-bounce delay-500">
          <Leaf className="w-4 h-4 text-accent/50" />
        </div>
      </div>

      <div className="relative z-10 container mx-auto px-4 flex items-center min-h-screen">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-primary">
              Carbon Coin
            </span>
            <br />
            <span className="text-2xl md:text-4xl font-semibold text-muted-foreground">
              Sustainable Future Through Action
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            Transform your environmental impact into measurable rewards. Participate in 
            cutting-edge sustainability initiatives, advance your knowledge through specialized 
            courses, and contribute to a carbon-neutral future.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              className="px-8 py-4 hover-elevate active-elevate-2"
              onClick={onGetStarted}
              data-testid="button-get-started"
            >
              Get Started
              <Leaf className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="px-8 py-4 hover-elevate active-elevate-2"
              onClick={onLearnMore}
              data-testid="button-learn-more"
            >
              Learn More
              <TreePine className="ml-2 w-5 h-5" />
            </Button>
          </div>

          <div className="mt-12 flex items-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-accent" />
              <span>Earn Carbon Coins</span>
            </div>
            <div className="flex items-center gap-2">
              <Leaf className="w-4 h-4 text-primary" />
              <span>Eco-Friendly Actions</span>
            </div>
            <div className="flex items-center gap-2">
              <TreePine className="w-4 h-4 text-primary" />
              <span>Grow Your Impact</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}