import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Cookie, Shield, X } from 'lucide-react';

interface CookieConsentProps {
  onAccept?: () => void;
  onDecline?: () => void;
}

export default function CookieConsent({ onAccept, onDecline }: CookieConsentProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if user has already given consent
    const hasConsent = localStorage.getItem('carbon-coin-cookie-consent');
    if (!hasConsent) {
      // Show after a brief delay for better UX
      setTimeout(() => setIsVisible(true), 1000);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('carbon-coin-cookie-consent', 'accepted');
    setIsVisible(false);
    onAccept?.();
    console.log('Cookies accepted');
  };

  const handleDecline = () => {
    localStorage.setItem('carbon-coin-cookie-consent', 'declined');
    setIsVisible(false);
    onDecline?.();
    console.log('Cookies declined');
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-end justify-center p-4">
      <Card className="w-full max-w-2xl mb-4 border-primary/20 bg-gradient-to-r from-background to-primary/5">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-2 rounded-full bg-primary/10 flex-shrink-0">
              <Cookie className="h-6 w-6 text-primary" />
            </div>
            
            <div className="flex-1 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">
                  Cookie Consent
                </h3>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleClose}
                  className="h-6 w-6 p-0"
                  data-testid="button-close-consent"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <p className="text-sm text-muted-foreground leading-relaxed">
                We use cookies to enhance your Carbon Coin experience, track your sustainability 
                progress, and provide personalized eco-friendly recommendations. Your data helps 
                us create a better platform for environmental action.
              </p>
              
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Shield className="h-3 w-3" />
                <span>Your privacy is protected and data is secured</span>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Button 
                  onClick={handleAccept}
                  className="flex-1 hover-elevate active-elevate-2"
                  data-testid="button-accept-cookies"
                >
                  Accept & Continue
                  <Cookie className="ml-2 h-4 w-4" />
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleDecline}
                  className="flex-1 hover-elevate active-elevate-2"
                  data-testid="button-decline-cookies"
                >
                  Decline
                </Button>
              </div>
              
              <p className="text-xs text-muted-foreground">
                You can change your preferences at any time in settings.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}