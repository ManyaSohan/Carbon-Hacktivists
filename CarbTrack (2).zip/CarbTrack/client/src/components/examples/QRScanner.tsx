import QRScanner from '../QRScanner';

export default function QRScannerExample() {
  return (
    <div className="max-w-md">
      <QRScanner 
        onScanSuccess={(coins) => console.log(`Earned ${coins} coins!`)}
      />
    </div>
  );
}