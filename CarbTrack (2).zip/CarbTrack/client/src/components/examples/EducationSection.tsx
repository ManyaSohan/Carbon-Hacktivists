import EducationSection from '../EducationSection';

export default function EducationSectionExample() {
  return (
    <div className="max-w-md">
      <EducationSection 
        userCoins={45}
        onStartCourse={(courseId) => console.log(`Starting course ${courseId}`)}
      />
    </div>
  );
}