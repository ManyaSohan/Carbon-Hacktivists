import HealthTracker from '../HealthTracker';

export default function HealthTrackerExample() {
  return (
    <div className="max-w-md">
      <HealthTracker 
        onLogActivity={(coins) => console.log(`Earned ${coins} coins from health activity!`)}
      />
    </div>
  );
}