import { useState } from 'react';
import Navigation from '../Navigation';

export default function NavigationExample() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  
  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        currentPage={currentPage}
        userCoins={142}
        onNavigate={(page) => setCurrentPage(page)}
        onLogout={() => console.log('Logout clicked')}
      />
      <div className="p-8">
        <h2 className="text-2xl font-bold mb-4">Current Page: {currentPage}</h2>
        <p className="text-muted-foreground">
          Navigation is responsive and includes mobile menu functionality.
        </p>
      </div>
    </div>
  );
}