import AnimatedTree from '../AnimatedTree';

export default function AnimatedTreeExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Lush Tree (High Coins)</h3>
        <AnimatedTree coinBalance={100} className="h-64" />
      </div>
      <div>
        <h3 className="text-lg font-semibold mb-4">Dry Tree (Low Coins)</h3>
        <AnimatedTree coinBalance={10} className="h-64" />
      </div>
    </div>
  );
}