import CookieConsent from '../CookieConsent';

export default function CookieConsentExample() {
  return (
    <div className="min-h-screen bg-background relative">
      <div className="p-8">
        <h2 className="text-2xl font-bold mb-4">Sample Page Content</h2>
        <p className="text-muted-foreground">
          This demonstrates how the cookie consent appears over page content.
        </p>
      </div>
      
      <CookieConsent 
        onAccept={() => console.log('Cookies accepted')}
        onDecline={() => console.log('Cookies declined')}
      />
    </div>
  );
}