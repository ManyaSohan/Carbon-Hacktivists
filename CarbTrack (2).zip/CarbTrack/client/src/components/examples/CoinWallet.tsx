import CoinWallet from '../CoinWallet';

export default function CoinWalletExample() {
  //todo: remove mock functionality
  const mockBadges = ['Eco Hackstar', 'Carbon Cracker', 'Green Genie'];
  
  return (
    <div className="max-w-md">
      <CoinWallet 
        balance={125}
        streak={7}
        todayEarned={15}
        badges={mockBadges}
      />
    </div>
  );
}