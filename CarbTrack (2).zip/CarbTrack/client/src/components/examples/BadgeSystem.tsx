import BadgeSystem from '../BadgeSystem';

export default function BadgeSystemExample() {
  return (
    <div className="max-w-2xl">
      <BadgeSystem />
    </div>
  );
}