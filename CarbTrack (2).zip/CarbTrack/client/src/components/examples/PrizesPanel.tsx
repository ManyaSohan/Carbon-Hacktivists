import PrizesPanel from '../PrizesPanel';

export default function PrizesPanelExample() {
  return (
    <div className="max-w-md">
      <PrizesPanel 
        userCoins={175}
        onRedeem={(prizeId) => console.log(`Redeeming prize ${prizeId}`)}
      />
    </div>
  );
}