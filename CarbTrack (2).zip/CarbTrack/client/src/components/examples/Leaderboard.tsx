import Leaderboard from '../Leaderboard';

export default function LeaderboardExample() {
  return (
    <div className="max-w-2xl">
      <Leaderboard showAll={true} />
    </div>
  );
}