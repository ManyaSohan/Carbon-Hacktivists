import HeroSection from '../HeroSection';

export default function HeroSectionExample() {
  return (
    <HeroSection 
      onGetStarted={() => console.log('Get Started clicked')}
      onLearnMore={() => console.log('Learn More clicked')}
    />
  );
}