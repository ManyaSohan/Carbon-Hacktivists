import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Coins, TrendingUp, Flame } from 'lucide-react';

interface CoinWalletProps {
  balance: number;
  streak: number;
  todayEarned: number;
  badges?: string[];
}

export default function CoinWallet({ balance, streak, todayEarned, badges = [] }: CoinWalletProps) {
  return (
    <Card className="hover-elevate" data-testid="card-wallet">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Carbon Wallet</CardTitle>
        <Coins className="h-6 w-6 text-primary" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Main Balance */}
          <div className="text-center">
            <div className="text-4xl font-bold text-primary mb-2 animate-pulse">
              {balance}
            </div>
            <p className="text-sm text-muted-foreground">Carbon Coins</p>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-lg font-semibold">{streak}</span>
              </div>
              <p className="text-xs text-muted-foreground">Day Streak</p>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center gap-1 mb-1">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span className="text-lg font-semibold">+{todayEarned}</span>
              </div>
              <p className="text-xs text-muted-foreground">Today</p>
            </div>
          </div>

          {/* Recent Badges */}
          {badges.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-2">Recent Badges</p>
              <div className="flex flex-wrap gap-2">
                {badges.slice(0, 3).map((badge, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {badge}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}