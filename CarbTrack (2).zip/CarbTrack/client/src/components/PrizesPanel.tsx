import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Gift, ExternalLink, Coins, BookOpen, HelpCircle, Calendar } from 'lucide-react';
import sponsorLogos from '@assets/generated_images/Tech_sponsor_logos_c0d9d9d6.png';

interface Prize {
  id: string;
  title: string;
  provider: string;
  type: 'course' | 'access' | 'questionbank';
  coinsRequired: number;
  description: string;
  available: boolean;
  icon: string;
}

interface PrizesPanelProps {
  userCoins: number;
  onRedeem?: (prizeId: string) => void;
}

export default function PrizesPanel({ userCoins, onRedeem }: PrizesPanelProps) {
  //todo: remove mock functionality
  const prizes: Prize[] = [
    { 
      id: '1', 
      title: 'AI/ML Course', 
      provider: 'IBM', 
      type: 'course', 
      coinsRequired: 200, 
      description: 'Complete IBM AI fundamentals certification',
      available: true,
      icon: 'book'
    },
    { 
      id: '2', 
      title: 'Web Development', 
      provider: 'Udemy', 
      type: 'course', 
      coinsRequired: 150, 
      description: 'Full-stack development course',
      available: true,
      icon: 'book'
    },
    { 
      id: '3', 
      title: 'Career Simulation', 
      provider: 'Forage', 
      type: 'course', 
      coinsRequired: 100, 
      description: 'Virtual work experience program',
      available: true,
      icon: 'book'
    },
    { 
      id: '4', 
      title: 'Data Science Track', 
      provider: 'Coursera', 
      type: 'course', 
      coinsRequired: 300, 
      description: 'Specialization in data science',
      available: true,
      icon: 'book'
    },
    { 
      id: '5', 
      title: 'Internship Prep', 
      provider: 'Internshala', 
      type: 'course', 
      coinsRequired: 120, 
      description: 'Interview preparation course',
      available: true,
      icon: 'book'
    },
    { 
      id: '6', 
      title: 'Library Access', 
      provider: 'Campus Library', 
      type: 'access', 
      coinsRequired: 50, 
      description: '2 months premium access',
      available: true,
      icon: 'calendar'
    },
    { 
      id: '7', 
      title: 'CSE Question Bank', 
      provider: 'Department Resources', 
      type: 'questionbank', 
      coinsRequired: 15, 
      description: 'Previous year questions & solutions',
      available: true,
      icon: 'help'
    },
    { 
      id: '8', 
      title: 'ECE Question Bank', 
      provider: 'Department Resources', 
      type: 'questionbank', 
      coinsRequired: 15, 
      description: 'Electronics & Communication questions',
      available: true,
      icon: 'help'
    },
    { 
      id: '9', 
      title: 'Mechanical Question Bank', 
      provider: 'Department Resources', 
      type: 'questionbank', 
      coinsRequired: 15, 
      description: 'Mechanical engineering question papers',
      available: true,
      icon: 'help'
    },
    { 
      id: '10', 
      title: 'Civil Question Bank', 
      provider: 'Department Resources', 
      type: 'questionbank', 
      coinsRequired: 15, 
      description: 'Civil engineering question bank',
      available: true,
      icon: 'help'
    },
  ];

  const getIcon = (iconName: string) => {
    const icons = {
      book: BookOpen,
      calendar: Calendar,
      help: HelpCircle,
    };
    const IconComponent = icons[iconName as keyof typeof icons] || Gift;
    return <IconComponent className="h-4 w-4" />;
  };

  const getTypeColor = (type: Prize['type']) => {
    const colors = {
      course: 'bg-blue-100 text-blue-800',
      access: 'bg-green-100 text-green-800',
      questionbank: 'bg-purple-100 text-purple-800'
    };
    return colors[type];
  };

  return (
    <Card className="hover-elevate" data-testid="card-prizes">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Prizes & Benefits</CardTitle>
        <Gift className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Sponsor logos preview */}
        <div className="text-center mb-4">
          <img 
            src={sponsorLogos} 
            alt="Sponsor company logos" 
            className="w-full h-16 object-cover rounded-lg opacity-70"
          />
          <p className="text-xs text-muted-foreground mt-2">
            Courses from leading tech companies
          </p>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {prizes.map((prize) => {
            const canRedeem = userCoins >= prize.coinsRequired;
            
            return (
              <div 
                key={prize.id}
                className="p-3 rounded-lg border bg-background"
                data-testid={`prize-${prize.id}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start gap-2 flex-1">
                    <div className="p-1 rounded bg-muted/50">
                      {getIcon(prize.icon)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm text-foreground">
                        {prize.title}
                      </h4>
                      <p className="text-xs text-muted-foreground mb-1">
                        {prize.provider}
                      </p>
                      <Badge variant="secondary" className={`text-xs ${getTypeColor(prize.type)}`}>
                        {prize.type}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-1 text-sm">
                      <Coins className="h-3 w-3 text-primary" />
                      <span className={canRedeem ? 'text-foreground' : 'text-muted-foreground'}>
                        {prize.coinsRequired}
                      </span>
                    </div>
                    <Button 
                      size="sm"
                      variant={canRedeem ? "default" : "outline"}
                      disabled={!canRedeem}
                      onClick={() => onRedeem?.(prize.id)}
                      className="h-6 text-xs hover-elevate active-elevate-2"
                      data-testid={`button-redeem-${prize.id}`}
                    >
                      {canRedeem ? 'Redeem' : 'Locked'}
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <p className="text-xs text-muted-foreground">
                  {prize.description}
                </p>
              </div>
            );
          })}
        </div>
        
        <div className="text-xs text-muted-foreground text-center">
          Redeem Carbon Coins for exclusive rewards and learning opportunities
        </div>
      </CardContent>
    </Card>
  );
}