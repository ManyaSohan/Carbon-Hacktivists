import { useState, useEffect } from 'react';

interface AnimatedTreeProps {
  coinBalance: number;
  className?: string;
}

export default function AnimatedTree({ coinBalance, className = '' }: AnimatedTreeProps) {
  const [treeState, setTreeState] = useState<'lush' | 'dry'>('dry');

  useEffect(() => {
    // Tree grows lush with more coins, becomes dry with fewer
    setTreeState(coinBalance >= 50 ? 'lush' : 'dry');
  }, [coinBalance]);

  return (
    <div className={`relative overflow-hidden rounded-xl border border-border/50 ${className}`}>
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10"></div>
      
      {/* SVG Tree Visualization */}
      <div className="relative w-full h-full flex items-center justify-center p-4">
        <svg 
          viewBox="0 0 200 200" 
          className={`w-full h-full transition-all duration-1000 ${treeState === 'lush' ? 'text-primary' : 'text-muted-foreground'}`}
          data-testid={`tree-${treeState}`}
        >
          {/* Tree trunk */}
          <rect x="90" y="140" width="20" height="50" fill="#8B4513" rx="2" />
          
          {/* Tree canopy - changes based on coin balance */}
          <circle 
            cx="100" 
            cy="120" 
            r={treeState === 'lush' ? "45" : "35"} 
            fill={treeState === 'lush' ? 'currentColor' : '#94a3b8'} 
            opacity={treeState === 'lush' ? '0.9' : '0.6'}
            className="transition-all duration-1000"
          />
          
          {/* Additional foliage for lush tree */}
          {treeState === 'lush' && (
            <>
              <circle cx="75" cy="110" r="25" fill="currentColor" opacity="0.7" />
              <circle cx="125" cy="110" r="25" fill="currentColor" opacity="0.7" />
              <circle cx="100" cy="95" r="20" fill="currentColor" opacity="0.8" />
            </>
          )}
          
          {/* Leaves falling for dry tree */}
          {treeState === 'dry' && (
            <>
              <circle cx="60" cy="160" r="3" fill="#94a3b8" opacity="0.5" />
              <circle cx="140" cy="170" r="2" fill="#94a3b8" opacity="0.4" />
              <circle cx="80" cy="180" r="2" fill="#94a3b8" opacity="0.3" />
            </>
          )}
          
          {/* Coins floating around lush tree */}
          {treeState === 'lush' && (
            <>
              <circle cx="50" cy="80" r="4" fill="#fbbf24" opacity="0.8" className="animate-bounce" style={{animationDelay: '0s'}} />
              <circle cx="150" cy="90" r="3" fill="#fbbf24" opacity="0.7" className="animate-bounce" style={{animationDelay: '0.5s'}} />
              <circle cx="130" cy="60" r="3" fill="#fbbf24" opacity="0.6" className="animate-bounce" style={{animationDelay: '1s'}} />
            </>
          )}
        </svg>
      </div>
      
      <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 border border-border/50">
        <p className="text-sm font-semibold text-foreground">
          {treeState === 'lush' ? '🌳 Sustainable Growth' : '🌱 Building Impact'}
        </p>
        <p className="text-xs text-muted-foreground">
          {coinBalance} Carbon Coins
        </p>
        <div className="mt-1 text-xs text-primary font-medium">
          {treeState === 'lush' ? 'Thriving Ecosystem' : 'Growing Potential'}
        </div>
      </div>
    </div>
  );
}