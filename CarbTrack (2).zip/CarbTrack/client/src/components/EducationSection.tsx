import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { BookOpen, Lock, Play, CheckCircle } from 'lucide-react';

interface Course {
  id: string;
  title: string;
  category: 'AI' | 'ML' | 'Cybersecurity' | 'Carbon Emission' | 'EVs';
  locked: boolean;
  progress: number;
  coinsRequired: number;
  coinsReward: number;
}

interface EducationSectionProps {
  userCoins: number;
  onStartCourse?: (courseId: string) => void;
}

export default function EducationSection({ userCoins, onStartCourse }: EducationSectionProps) {
  //todo: remove mock functionality
  const courses: Course[] = [
    { id: '1', title: 'AI Fundamentals', category: 'AI', locked: false, progress: 65, coinsRequired: 0, coinsReward: 20 },
    { id: '2', title: 'Machine Learning Basics', category: 'ML', locked: false, progress: 30, coinsRequired: 10, coinsReward: 25 },
    { id: '3', title: 'Cybersecurity Essentials', category: 'Cybersecurity', locked: true, progress: 0, coinsRequired: 50, coinsReward: 30 },
    { id: '4', title: 'Carbon Footprint Analysis', category: 'Carbon Emission', locked: false, progress: 0, coinsRequired: 20, coinsReward: 35 },
    { id: '5', title: 'Electric Vehicle Technology', category: 'EVs', locked: true, progress: 0, coinsRequired: 75, coinsReward: 40 },
  ];

  const getCategoryColor = (category: Course['category']) => {
    const colors = {
      'AI': 'bg-blue-100 text-blue-800',
      'ML': 'bg-purple-100 text-purple-800',
      'Cybersecurity': 'bg-red-100 text-red-800',
      'Carbon Emission': 'bg-green-100 text-green-800',
      'EVs': 'bg-orange-100 text-orange-800'
    };
    return colors[category];
  };

  return (
    <Card className="hover-elevate" data-testid="card-education">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Education Hub</CardTitle>
        <BookOpen className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3">
          {courses.map((course) => {
            const canUnlock = userCoins >= course.coinsRequired;
            const isCompleted = course.progress === 100;
            
            return (
              <div 
                key={course.id} 
                className={`p-3 rounded-lg border ${course.locked && !canUnlock ? 'bg-muted/50' : 'bg-background'}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className={`font-medium text-sm ${course.locked && !canUnlock ? 'text-muted-foreground' : 'text-foreground'}`}>
                      {course.title}
                    </h4>
                    <Badge variant="secondary" className={`text-xs mt-1 ${getCategoryColor(course.category)}`}>
                      {course.category}
                    </Badge>
                  </div>
                  
                  {course.locked && !canUnlock ? (
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Lock className="h-4 w-4" />
                      <span className="text-xs">{course.coinsRequired} coins</span>
                    </div>
                  ) : isCompleted ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <Button 
                      size="sm" 
                      variant={course.progress > 0 ? "default" : "outline"}
                      onClick={() => onStartCourse?.(course.id)}
                      className="h-6 text-xs hover-elevate active-elevate-2"
                      data-testid={`button-start-course-${course.id}`}
                    >
                      {course.progress > 0 ? 'Continue' : 'View'}
                      <Play className="ml-1 h-3 w-3" />
                    </Button>
                  )}
                </div>
                
                {course.progress > 0 && (
                  <div className="space-y-1">
                    <Progress value={course.progress} className="h-1" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{course.progress}% complete</span>
                      <span>+{course.coinsReward} coins</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        <div className="text-xs text-muted-foreground text-center">
          Unlock courses with Carbon Coins • Earn rewards upon completion
        </div>
      </CardContent>
    </Card>
  );
}